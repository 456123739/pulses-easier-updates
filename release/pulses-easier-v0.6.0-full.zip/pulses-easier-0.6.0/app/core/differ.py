"""
differ.py — 新旧版本差异比对
------------------------------------------------
数据源模型：
  index 和 overrides 是**互补**的：
    - 有下载链接的文件 → 在 index 里
    - 下不到的文件   → 在 overrides 里
  新版本某文件夹里的文件清单 = index 里该文件夹直接文件
                              ∪ overrides 里该文件夹直接文件

输出粒度：
  白名单文件夹：单层比对
    - 直接子文件：文件级 Change（is_folder_level=False）
    - 直接子文件夹：文件夹级 Change（is_folder_level=True）
  非白名单文件夹：整体文件夹级 Change
  只在新包有 → ADDED
  只在旧包有 → DELETED（仅当"更新包里有这个顶层文件夹"时输出；
                       顶层文件夹不在更新包里的，不输出）
  双侧都有且不同 → MODIFIED

根目录散文件：
  只在新包有 → ADDED
  双侧都有 → MODIFIED
  只在旧包有 → 保留（玩家本地配置，不输出 DELETED）

算法一致：
  - index 声明 sha1 → 本地也算 sha1
  - index 声明 sha256 → 本地也算 sha256
  - index 没声明 → 两侧都 sha1
"""

import hashlib
import os
import threading
from collections.abc import Callable
from concurrent.futures import Future, ThreadPoolExecutor
from dataclasses import dataclass, field
from pathlib import Path

from ..config import ChangeKind, is_local_only_dir, is_local_only_name
from ..utils.files import iter_files

DEFAULT_WHITELIST = ["mods"]


@dataclass
class Change:
    rel_path: Path
    kind: ChangeKind
    is_folder_level: bool = False  # True=文件夹级比对，False=文件级比对


@dataclass
class DiffResult:
    added: list[Change] = field(default_factory=list)
    modified: list[Change] = field(default_factory=list)
    deleted: list[Change] = field(default_factory=list)

    @property
    def total(self) -> int:
        return len(self.added) + len(self.modified) + len(self.deleted)


# ----------------------------------------------------------------------
# 哈希工具
# ----------------------------------------------------------------------
BLAKE2B_DIGEST_SIZE = 16      # 与 hashing.py 保持一致（128 位）


def _new_hasher(algo: str):
    """按算法名创建哈希对象；blake2b 固定 128 位以兼容导出包清单。"""
    if algo == "blake2b":
        return hashlib.blake2b(digest_size=BLAKE2B_DIGEST_SIZE)
    return hashlib.new(algo)


def _hash_file(path: Path, algo: str = "sha1") -> str:
    try:
        h = _new_hasher(algo)
    except Exception:  # noqa: BLE001
        return ""
    try:
        with open(path, "rb") as f:
            while chunk := f.read(1 << 20):
                h.update(chunk)
    except OSError:
        return ""
    return h.hexdigest()


def _folder_manifest(folder: Path | None) -> tuple[list[tuple[str, int]], int]:
    """
    遍历目录，返回 ([(相对路径, 大小)], 总字节)。

    不存在/不可读 → ([], 0)。
    """
    entries: list[tuple[str, int]] = []
    total = 0
    if folder is None:
        return entries, total
    folder = Path(folder)
    if not folder.is_dir():
        return entries, total
    try:
        for dirpath, _dirnames, filenames in os.walk(folder):
            for name in filenames:
                abs_path = Path(dirpath) / name
                try:
                    rel = abs_path.relative_to(folder).as_posix()
                    size = abs_path.stat().st_size
                except OSError:
                    continue
                entries.append((rel, size))
                total += size
    except OSError:
        return [], 0
    entries.sort()
    return entries, total


# 超过这个体积就只做"路径+大小"比较（避免为了确认一致性读入 GB 级内容）
_FOLDER_DEEP_MAX_BYTES = 256 * 1024 * 1024


def folder_hash(folder: Path | None, content: bool = True) -> str:
    """
    文件夹级哈希：相对路径 + 大小（+ 内容 SHA-1）。

    content=False 时只算路径与大小（不读内容，快）。
    **刻意不包含 mtime**：更新包是现解压出来的，zip 不还原 mtime，
    一旦把 mtime 算进摘要，内容完全相同的目录也会被判定为
    「已修改」，进而触发整目录替换（历史上导致过玩家本地文件被清空）。
    """
    entries, _total = _folder_manifest(folder)
    h = hashlib.sha256()
    for rel, size in entries:
        h.update(rel.encode("utf-8"))
        h.update(b"\x00")
        h.update(str(size).encode("ascii"))
        if content and folder is not None:
            h.update(b"\x00")
            h.update(_hash_file(Path(folder) / rel, "sha1").encode("ascii"))
        h.update(b"\n")
    return h.hexdigest()


def folders_differ(a: Path | None, b: Path | None) -> bool:
    """
    两个目录的**内容**是否不同。

    两级判定：
      1) 先用「相对路径 + 大小」排除明显差异（廉价，不读内容）；
      2) 相同再逐个文件比内容哈希（消除"同名同大小但内容不同"
         漏判，同时不受 mtime 影响）。
    目录总体积超过 _FOLDER_DEEP_MAX_BYTES 时只做第 1 级。
    """
    ea, ta = _folder_manifest(a)
    eb, tb = _folder_manifest(b)
    if not ea and not eb:
        return False
    if ea != eb:
        return True
    if ta > _FOLDER_DEEP_MAX_BYTES or tb > _FOLDER_DEEP_MAX_BYTES:
        return False
    return folder_hash(a, content=True) != folder_hash(b, content=True)


def _pick_hash(hashes: dict | None) -> tuple[str | None, str | None]:
    """从 index 哈希里挑一个：优先 sha1（更快），最后才是 blake2b"""
    if not isinstance(hashes, dict):
        return None, None
    for algo in ("sha1", "sha256", "sha512", "blake2b"):
        v = hashes.get(algo)
        if isinstance(v, str) and v:
            return algo, v
    return None, None


def _list_entries(folder: Path | None
                  ) -> tuple[dict[str, Path], dict[str, Path]]:
    """列出文件夹直接子项：({文件名: 路径}, {子目录名: 路径})"""
    files: dict[str, Path] = {}
    dirs: dict[str, Path] = {}
    if folder is None or not folder.is_dir():
        return files, dirs
    try:
        for entry in folder.iterdir():
            if entry.is_file():
                files[entry.name] = entry
            elif entry.is_dir():
                dirs[entry.name] = entry
    except OSError:
        pass
    return files, dirs


# ----------------------------------------------------------------------
# index 哈希表预处理：按顶层文件夹切分 + 收集深层目录
# ----------------------------------------------------------------------
def _split_index_by_top(
    index_hashes: dict[str, dict],
) -> tuple[dict[str, dict[str, dict]], dict[str, set[str]],
           dict[str, dict]]:
    """
    预遍历 index_hashes 一次，产出：
      - by_top: {top_name: {rel_path: hashes}}
      - deep_dirs: {top_name: {相对 top 的目录路径集合}}
      - root_files: {文件名: hashes}   ← 根目录散文件（旧实现直接丢弃，
        导致根文件只能"按存在性"判断，内容改了也不一定能发现）
    """
    by_top: dict[str, dict[str, dict]] = {}
    deep_dirs: dict[str, set[str]] = {}
    root_files: dict[str, dict] = {}

    for rel, hashes in index_hashes.items():
        if "/" not in rel:
            if rel:
                root_files[rel] = hashes
            continue
        top, _, sub = rel.partition("/")
        if not top or not sub:
            continue
        by_top.setdefault(top, {})[rel] = hashes

        parts = sub.split("/")
        if len(parts) >= 2:
            acc = ""
            dirs = deep_dirs.setdefault(top, set())
            for seg in parts[:-1]:
                acc = seg if not acc else acc + "/" + seg
                dirs.add(acc)

    return by_top, deep_dirs, root_files


# ----------------------------------------------------------------------
# 白名单文件夹比对（单层）
# ----------------------------------------------------------------------
def _diff_whitelist_dir(
    old_dir: Path | None,
    new_dir: Path | None,
    top_name: str,
    index_by_top: dict[str, dict[str, dict]],
    index_deep_dirs: set[str],
    threads: int,
    progress: Callable[[int, int], None] | None = None,
) -> tuple[list[Change], list[Change], list[Change]]:
    """
    对白名单文件夹做单层比对，返回 (added, modified, deleted)。
    """
    added: list[Change] = []
    modified: list[Change] = []
    deleted: list[Change] = []

    old_files, old_dirs = _list_entries(old_dir)
    new_files, new_dirs = _list_entries(new_dir)

    prefix = top_name + "/"
    index_direct: dict[str, dict] = {}
    for rel, hashes in index_by_top.get(top_name, {}).items():
        if not rel.startswith(prefix):
            continue
        sub = rel[len(prefix):]
        if "/" in sub:
            continue
        index_direct[sub] = hashes

    index_dirs: set[str] = set()
    for d in index_deep_dirs:
        first = d.split("/", 1)[0]
        if first:
            index_dirs.add(first)

    new_file_names = set(new_files.keys()) | set(index_direct.keys())
    old_file_names = set(old_files.keys())

    to_compare: list[tuple[str, Path, str, str]] = []

    for name in sorted(new_file_names):
        full_rel = top_name + "/" + name
        local = old_files.get(name)

        target_h: str | None = None
        algo = "sha1"

        idx_entry = index_direct.get(name)
        if idx_entry is not None:
            algo_h, hash_v = _pick_hash(idx_entry)
            if hash_v:
                target_h = hash_v
                algo = algo_h or "sha1"

        if target_h is None:
            src = new_files.get(name)
            if src is not None:
                target_h = _hash_file(src, "sha1")
                algo = "sha1"

        if not target_h:
            if local is None:
                added.append(Change(Path(full_rel), ChangeKind.ADDED))
            else:
                modified.append(Change(Path(full_rel),
                                       ChangeKind.MODIFIED))
            continue

        if local is None:
            added.append(Change(Path(full_rel), ChangeKind.ADDED))
        else:
            to_compare.append((full_rel, local, target_h, algo))

    for name in sorted(old_file_names - new_file_names):
        full_rel = top_name + "/" + name
        deleted.append(Change(Path(full_rel), ChangeKind.DELETED))

    if to_compare:
        total = len(to_compare)
        counter = {"n": 0}
        lock = threading.Lock()

        def _one(item):
            full_rel, path, target_h, algo = item
            local_h = _hash_file(path, algo)
            return full_rel, local_h, target_h

        with ThreadPoolExecutor(max_workers=max(1, threads)) as pool:
            futures: list[Future] = [pool.submit(_one, it)
                                     for it in to_compare]
            for fut in futures:
                try:
                    full_rel, local_h, target_h = fut.result()
                except Exception:  # noqa: BLE001, S112
                    continue

                with lock:
                    counter["n"] += 1
                    d = counter["n"]
                if progress:
                    try:
                        progress(d, total)
                    except Exception:  # noqa: BLE001, S110
                        pass

                if local_h and local_h != target_h:
                    modified.append(
                        Change(Path(full_rel), ChangeKind.MODIFIED))

    effective_new_dirs = set(new_dirs.keys()) | index_dirs
    all_subdirs = set(old_dirs) | effective_new_dirs

    for sub in sorted(all_subdirs):
        old_sub = old_dirs.get(sub)
        new_sub = new_dirs.get(sub)
        full_rel = top_name + "/" + sub

        if sub in index_dirs and new_sub is None:
            if old_sub is None:
                added.append(Change(Path(full_rel), ChangeKind.ADDED,
                                    is_folder_level=True))
            continue

        if new_sub and not old_sub:
            added.append(Change(Path(full_rel), ChangeKind.ADDED,
                                is_folder_level=True))
        elif old_sub and not new_sub:
            deleted.append(Change(Path(full_rel), ChangeKind.DELETED,
                                  is_folder_level=True))
        else:
            if folders_differ(old_sub, new_sub):
                modified.append(Change(Path(full_rel), ChangeKind.MODIFIED,
                                       is_folder_level=True))

    return added, modified, deleted


# ----------------------------------------------------------------------
# 目录枚举
# ----------------------------------------------------------------------
def _top_dirs(root: Path) -> dict[str, Path]:
    result: dict[str, Path] = {}
    if not root.is_dir():
        return result
    try:
        for entry in root.iterdir():
            if entry.is_dir() and not is_local_only_dir(entry.name):
                result[entry.name] = entry
    except OSError:
        pass
    return result


def _root_files(root: Path) -> list[Path]:
    if not root.is_dir():
        return []
    result: list[Path] = []
    try:
        for entry in root.iterdir():
            # 本地专属文件（更新未完成凭证等）永不参与比对
            if entry.is_file() and not is_local_only_name(entry.name):
                result.append(Path(entry.name))
    except OSError:
        pass
    return result


# ----------------------------------------------------------------------
# 主比对
# ----------------------------------------------------------------------
def diff_packs_parallel(
    old_root: Path,
    new_root: Path,
    whitelist: list[str] | None = None,
    index_hashes: dict[str, dict] | None = None,
    threads: int = 16,
    progress: Callable[[int, int, str], None] | None = None,
    folder_hashes: dict[str, str] | None = None,
) -> DiffResult:
    """
    folder_hashes：更新包 `ea_hashes.json` 里记录的**顶层文件夹内容哈希**
    （由开发者端用同一算法算出）。命中时只需算本地一侧的哈希即可判定，
    省掉一半读取。
    """
    old_root, new_root = Path(old_root), Path(new_root)
    wl = list(whitelist) if whitelist else list(DEFAULT_WHITELIST)
    wl_top = {p.split("/", 1)[0] for p in wl if p}
    idx = index_hashes or {}
    f_hashes = folder_hashes or {}

    index_by_top, index_deep_dirs, index_root_files = \
        _split_index_by_top(idx)

    def _p(done: int, total: int, phase: str):
        if progress:
            try:
                progress(done, total, phase)
            except Exception:  # noqa: BLE001, S110
                pass

    old_dirs = _top_dirs(old_root)
    new_dirs = _top_dirs(new_root)
    all_names = sorted(set(old_dirs) | set(new_dirs) | set(index_by_top))
    total_dirs = len(all_names)

    result = DiffResult()

    for i, name in enumerate(all_names):
        has_old = name in old_dirs
        has_new = name in new_dirs
        old_dir = old_dirs.get(name)
        new_dir = new_dirs.get(name)
        has_index = name in index_by_top

        if not has_old and (has_new or has_index):
            if name in wl_top:
                idx_files = index_by_top.get(name, {})
                if idx_files:
                    for rel in sorted(idx_files.keys()):
                        result.added.append(
                            Change(Path(rel), ChangeKind.ADDED,
                                   is_folder_level=False))
                if new_dir:
                    try:
                        existing = set()
                        if idx_files:
                            for rel in idx_files:
                                sub = rel[len(name) + 1:]
                                existing.add(sub)
                        for rel in iter_files(new_dir):
                            rel_str = rel.as_posix()
                            if rel_str in existing:
                                continue
                            result.added.append(
                                Change(Path(name) / rel, ChangeKind.ADDED,
                                       is_folder_level=False))
                    except Exception:  # noqa: BLE001
                        if not idx_files:
                            result.added.append(
                                Change(Path(name), ChangeKind.ADDED,
                                       is_folder_level=True))
            else:
                result.added.append(Change(Path(name), ChangeKind.ADDED,
                                           is_folder_level=True))
            _p(i + 1, max(1, total_dirs), "merge")
            continue

        if has_old and not has_new and not has_index:
            _p(i + 1, max(1, total_dirs), "merge")
            continue

        if name in wl_top:
            added, modified, deleted = _diff_whitelist_dir(
                old_dir, new_dir, name,
                index_by_top, index_deep_dirs.get(name, set()),
                threads)
            result.added.extend(added)
            result.modified.extend(modified)
            result.deleted.extend(deleted)
        else:
            recorded = f_hashes.get(name, "")
            if recorded:
                # 极少数情况：记录值算的是"新包侧"，直接和本地侧比
                same = bool(old_dir) and folder_hash(old_dir) == recorded
                if not same:
                    result.modified.append(
                        Change(Path(name), ChangeKind.MODIFIED,
                               is_folder_level=True))
            elif folders_differ(old_dir, new_dir):
                result.modified.append(
                    Change(Path(name), ChangeKind.MODIFIED,
                           is_folder_level=True))

        _p(i + 1, max(1, total_dirs), "merge")

    # 根目录散文件：旧实现把"两侧都有"一律判 MODIFIED（从不比内容），
    # 于是每次都会重写 options.txt 之类的文件。现在按内容比对：
    # index 里声明过哈希就用它，否则两侧各算一次 sha1。
    old_files = set(_root_files(old_root))
    new_files = set(_root_files(new_root))
    for rel in sorted(new_files - old_files):
        result.added.append(Change(rel, ChangeKind.ADDED,
                                   is_folder_level=False))
    for rel in sorted(old_files & new_files):
        name = rel.name
        target_h: str | None = None
        algo = "sha1"
        idx_entry = index_root_files.get(name)
        if idx_entry is not None:
            algo_h, hash_v = _pick_hash(idx_entry)
            if hash_v:
                target_h, algo = hash_v, (algo_h or "sha1")
        if not target_h:
            target_h = _hash_file(new_root / rel, "sha1")
            algo = "sha1"
        if not target_h:
            # 算不出目标哈希（读失败）：保守判"需更新"
            result.modified.append(Change(rel, ChangeKind.MODIFIED,
                                          is_folder_level=False))
            continue
        local_h = _hash_file(old_root / rel, algo)
        if not local_h or local_h != target_h:
            result.modified.append(Change(rel, ChangeKind.MODIFIED,
                                          is_folder_level=False))

    return result


def diff_packs(old_root: Path, new_root: Path,
               whitelist: list[str] | None = None,
               index_hashes: dict[str, dict] | None = None,
               progress: Callable[[int, int, str], None] | None = None,
               folder_hashes: dict[str, str] | None = None
               ) -> DiffResult:
    return diff_packs_parallel(old_root, new_root,
                               whitelist=whitelist,
                               index_hashes=index_hashes,
                               threads=1, progress=progress,
                               folder_hashes=folder_hashes)