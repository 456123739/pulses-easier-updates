"""
test_basic.py — 基础测试：编译、全模块导入、启动链路、配置一致性。

在没有图形环境（无 tkinter / 无 X）的机器上，用桩模块覆盖第三方 GUI 依赖，
只验证「导入期错误 / 语法错误 / 配置漂移」，不做界面渲染。

运行：  python3 tests/test_basic.py
"""

import compileall
import importlib
import inspect
import pkgutil
import sys
import tempfile
import unittest
from pathlib import Path
from typing import ClassVar

_HERE = Path(__file__).resolve().parent
_ROOT = _HERE.parent
sys.path.insert(0, str(_ROOT))
sys.path.insert(0, str(_HERE))

import stubs

GUI_MODULES = ("customtkinter",)                # 需要桩的第三方包


class TestCompile(unittest.TestCase):
    def test_compileall(self):
        ok = compileall.compile_dir(str(_ROOT / "app"), quiet=2,
                                    force=True)
        self.assertTrue(ok, "app/ 下存在语法错误")
        ok = compileall.compile_file(str(_ROOT / "main.py"), quiet=2,
                                     force=True)
        self.assertTrue(ok, "main.py 存在语法错误")


class TestImportsCore(unittest.TestCase):
    """核心模块用真实依赖导入（不得依赖 GUI 库）。"""

    def test_core_modules_import(self):
        import app
        failed = []
        count = 0
        for m in pkgutil.walk_packages(app.__path__, "app."):
            if ".ui" in m.name:
                continue
            try:
                importlib.import_module(m.name)
                count += 1
            except Exception as e:  # noqa: BLE001
                failed.append((m.name, f"{type(e).__name__}: {e}"))
        self.assertGreater(count, 15)
        self.assertEqual(failed, [], f"核心模块导入失败：{failed}")

    def test_downloader_does_not_import_gui(self):
        import app.core.downloader as dl
        mods = {m for m in sys.modules}
        for name in ("customtkinter", "tkinter"):
            if name in mods:
                # 只要 downloader 自己没有引用即可
                src = Path(dl.__file__).read_text(encoding="utf-8")
                self.assertNotIn(f"import {name}", src)


class TestImportsGui(unittest.TestCase):
    """UI 模块用桩依赖导入：抓导入期错误、模块级表达式错误。"""

    @classmethod
    def setUpClass(cls):
        stubs.install()

    def test_ui_modules_import(self):
        import app
        failed = []
        count = 0
        for m in pkgutil.walk_packages(app.__path__, "app."):
            if ".ui" not in m.name:
                continue
            try:
                importlib.import_module(m.name)
                count += 1
            except Exception as e:  # noqa: BLE001
                failed.append((m.name, f"{type(e).__name__}: {e}"))
        self.assertGreater(count, 20, "UI 模块数量异常")
        self.assertEqual(failed, [], f"UI 模块导入失败：{failed}")

    def test_main_module_import(self):
        mod = importlib.import_module("main")
        self.assertTrue(hasattr(mod, "main"))
        self.assertTrue(hasattr(mod, "_pick_app_base"))
        base, dnd = mod._pick_app_base()
        self.assertTrue(inspect.isclass(base))
        self.assertIsInstance(dnd, bool)


class TestStartupChain(unittest.TestCase):
    """启动链路契约：main.py 依赖的那些入口必须存在且可组合。"""

    @classmethod
    def setUpClass(cls):
        stubs.install()
        cls._tmp = tempfile.TemporaryDirectory(prefix="easier-startup-")
        cls._restore = stubs.isolate_user_dirs(cls._tmp.name)

    @classmethod
    def tearDownClass(cls):
        cls._restore()
        cls._tmp.cleanup()

    def test_window_class_can_be_composed(self):
        import main as main_mod
        from app.ui.main_window import MainWindow
        AppBase, _dnd = main_mod._pick_app_base()
        WindowClass = type("WindowClass", (MainWindow, AppBase), {})
        self.assertTrue(issubclass(WindowClass, MainWindow))

    def test_mainwindow_required_hooks(self):
        from app.ui.main_window import MainWindow
        # withdraw / deiconify / mainloop 由 Tk 基类提供，这里只查 MainWindow 自己的
        for name in ("prepare_offscreen_warmup", "on_boot_done",
                     "get_boot_tasks"):
            self.assertTrue(hasattr(MainWindow, name),
                            f"MainWindow 缺少 {name}")

    def test_splash_signature(self):
        from app.ui.splash import SplashScreen
        sig = inspect.signature(SplashScreen.__init__)
        self.assertIn("on_done", sig.parameters)
        self.assertIn("boot_tasks", sig.parameters)

    def test_splash_progress_never_tops_out(self):
        """伪进度：一直逼近但永远到不了顶，只有启动完成才补满。"""
        from app.ui.splash import _PROGRESS_CAP, progress_at
        self.assertEqual(progress_at(0), 0.0)
        vals = [progress_at(t) for t in range(0, 4000, 50)]
        self.assertLess(max(vals), _PROGRESS_CAP)
        self.assertLess(_PROGRESS_CAP, 1.0)
        self.assertGreater(progress_at(2000), progress_at(300))  # 大趋势向上
        self.assertGreater(progress_at(4000), 0.8)               # 也不能磨洋工

    def test_splash_progress_is_smooth(self):
        """不能有跳变（观感上要"灵动"，不是一格一格蹦）。"""
        from app.ui.splash import _PROGRESS_CAP, progress_at
        prev = 0.0
        for t in range(0, 3000, 33):
            v = progress_at(t)
            self.assertGreaterEqual(v, 0.0)
            self.assertLessEqual(v, _PROGRESS_CAP)
            self.assertLess(abs(v - prev), 0.06, f"t={t} 跳变过大")
            prev = v

    def test_splash_ease_out_cubic(self):
        from app.ui.splash import ease_out_cubic
        self.assertEqual(ease_out_cubic(0.0), 0.0)
        self.assertEqual(ease_out_cubic(1.0), 1.0)
        self.assertGreater(ease_out_cubic(0.5), 0.5)   # 前段快、后段收
        self.assertEqual(ease_out_cubic(-1.0), 0.0)    # 越界夹紧
        self.assertEqual(ease_out_cubic(2.0), 1.0)

    def test_splash_bar_stays_inside_logo(self):
        """进度条必须比 logo 窄、居中、且完整落在 logo 范围内。"""
        from app.ui.splash import _BAR_WIDTH_RATIO, bar_geometry
        logo_x, logo_w = 30, 640
        x, w = bar_geometry(logo_w, logo_x)
        self.assertLess(w, logo_w)
        self.assertGreaterEqual(x, logo_x)
        self.assertLessEqual(x + w, logo_x + logo_w)
        self.assertAlmostEqual(w / logo_w, _BAR_WIDTH_RATIO, places=2)
        self.assertAlmostEqual(x - logo_x, (logo_x + logo_w) - (x + w),
                               delta=1)  # 左右留白相等 = 居中

    def test_boot_tasks_shape(self):
        """boot_tasks 需要是可迭代的 (title, callable) 序列。"""
        src = (_ROOT / "app" / "ui" / "main_window.py").read_text(
            encoding="utf-8")
        self.assertIn("def get_boot_tasks", src)
        self.assertIn("def on_boot_done", src)

    def test_window_constructs_and_boots_under_stubs(self):
        """
        用桩模块把 main.py 的启动链路真正跑一遍：
            组类 → 构造主窗口 → prepare_offscreen_warmup（双端预热）
            → get_boot_tasks → 逐个跑 boot 任务
        能抓出构造期 / 预热期 / 引导期的 Python 级错误（NameError、
        AttributeError、类型错误等）。注意：**不覆盖真实 Tk 渲染**。
        """
        import main as main_mod
        from app.ui.main_window import MainWindow
        AppBase, _dnd = main_mod._pick_app_base()
        WindowClass = type("WindowClass", (MainWindow, AppBase), {})
        app = WindowClass()
        app.prepare_offscreen_warmup()
        tasks = app.get_boot_tasks()
        self.assertIsInstance(tasks, list)
        self.assertGreaterEqual(len(tasks), 3)
        for item in tasks:
            title, fn = item
            self.assertIsInstance(title, str)
            self.assertTrue(callable(fn), f"boot 任务 {title} 不可调用")
            try:
                fn()
            except Exception as e:  # noqa: BLE001
                self.fail(f"boot 任务「{title}」抛异常："
                          f"{type(e).__name__}: {e}")


class TestUiContract(unittest.TestCase):
    """player_view / slot_panel / downloader 三者之间的接口契约。"""

    @classmethod
    def setUpClass(cls):
        stubs.install()

    def test_slot_panel_signature(self):
        from app.ui.widgets.slot_panel import SlotPanel
        sig = inspect.signature(SlotPanel.__init__)
        self.assertIn("slots", sig.parameters)
        self.assertIn("on_toggle", sig.parameters)
        for name in ("set_slots", "slot_count", "update"):
            self.assertTrue(hasattr(SlotPanel, name),
                            f"SlotPanel 缺少 {name}")

    def test_player_view_slot_bridge(self):
        from app.ui.player_view import PlayerView
        for name in ("_toggle_slot_panel", "_on_slot_toggle",
                     "_do_slot_refresh", "_on_byte_progress",
                     "_update_download_progress", "_on_download_done"):
            self.assertTrue(hasattr(PlayerView, name),
                            f"PlayerView 缺少 {name}")
        sig = inspect.signature(PlayerView._on_slot_toggle)
        self.assertEqual(list(sig.parameters), ["self", "expand"])

    def test_player_view_calls_download_files_with_expected_kwargs(self):
        """调用点必须经引擎注册表，且回调参数一个都不能少（两条引擎同签名）。"""
        src = (_ROOT / "app" / "ui" / "player_view.py").read_text(
            encoding="utf-8")
        self.assertIn("from ..core.downloader import DownloadTask", src)
        self.assertIn("self._engine_module().download_files(", src,
                      "下载必须走选中的引擎，不能写死 RideX")
        for kwarg in ("target_dir=", "threads=", "progress=", "log=",
                      "byte_progress=", "should_abort=",
                      "on_file_started=", "on_file_done=",
                      "on_file_failed="):
            self.assertIn(kwarg, src, f"player_view 没有传 {kwarg}")

    def test_player_view_result_semantics(self):
        """
        调用方按 `成功 = len(results) - len(failed)` 统计，并靠
        `on_file_done`（**只在成功时触发**）收集已完成文件；
        返回列表里每个任务恰好一条结果（成功也要返回）。
        """
        src = (_ROOT / "app" / "ui" / "player_view.py").read_text(
            encoding="utf-8")
        self.assertIn("self._mark_completed(task.rel_path)", src)
        self.assertIn("def _mark_completed", src)
        self.assertIn("if r.ok:", src)
        self.assertIn("len(results) - len(failed)", src)
        self.assertIn("failed = [r for r in results if not r.ok and not r.aborted]",
                      src)

    def test_slot_panel_uses_on_toggle(self):
        src = (_ROOT / "app" / "ui" / "widgets" / "slot_panel.py").read_text(
            encoding="utf-8")
        self.assertIn("self._on_toggle(False)", src)
        self.assertIn("on_toggle", src)


class TestPendingLogic(unittest.TestCase):
    """
    「下不下来的文件交还给用户」这块的契约与匹配逻辑。

    纯逻辑已从 download_panel 迁到 app/core/pending.py（v0.5.0 起界面改为
    「受阻提示条 + 补入子窗口」），断言保持不变。
    """

    @classmethod
    def setUpClass(cls):
        stubs.install()
        from app.core import pending as pending_logic
        cls.P = pending_logic
        from app.ui.widgets.pending_window import PendingWindow
        cls.Window = PendingWindow

    def _panel(self, items, drop_handler=None, notice=None):
        calls = []

        def handler(rel, path):
            calls.append((rel, str(path)))
            if drop_handler is None:
                return True
            return drop_handler(rel, path)

        panel = self.Window(None, mode="wait", items=items,
                            on_file_dropped=handler,
                            on_retry=None, on_all_resolved=None,
                            on_give_up=None, on_dismiss=None,
                            on_hide=None, on_notice=notice)
        return panel, calls

    @staticmethod
    def _item(rel, urls, error="boom"):
        return {"rel": rel, "urls": list(urls), "error": error}

    # -- 名称归一化 -----------------------------------------------------
    def test_normalize_keeps_version_numbers(self):
        P = self.P
        self.assertEqual(P.normalize_download_name("create-1.20.1-6.0.7.jar"),
                         "create-1.20.1-6.0.7.jar")
        self.assertEqual(
            P.normalize_download_name("jei-1.21.1-fabric-19.57.0.451.jar"),
            "jei-1.21.1-fabric-19.57.0.451.jar")

    def test_normalize_strips_browser_copy_suffix(self):
        P = self.P
        want = "create-1.20.1-6.0.7.jar"
        for name in ("create-1.20.1-6.0.7 (1).jar",
                     "create-1.20.1-6.0.7(2).jar",
                     "create-1.20.1-6.0.7 - 副本.jar",
                     "create-1.20.1-6.0.7 - copy.jar",
                     "Create-1.20.1-6.0.7.JAR"):
            self.assertEqual(P.normalize_download_name(name), want, name)

    # -- 链接 -----------------------------------------------------------
    def test_links_dedupe_all_sources(self):
        P = self.P
        urls = ["https://a/1.jar", "https://b/2.jar", "https://a/1.jar", ""]
        self.assertEqual(P.dedupe_urls(urls),
                         ["https://a/1.jar", "https://b/2.jar"])

    def test_links_text_has_filename_and_all_sources(self):
        P = self.P
        text = P.links_text("mods/a.jar",
                            ["https://a/1.jar", "https://mirror/2.jar"])
        self.assertTrue(text.startswith("# a.jar"))
        self.assertIn("https://a/1.jar", text)
        self.assertIn("https://mirror/2.jar", text)

    def test_source_rows_show_names(self):
        P = self.P
        rows = P.source_rows(["https://cdn.modrinth.com/a.jar",
                              "https://mod.mcimirror.top/a.jar"])
        self.assertEqual([n for n, _u in rows],
                         ["Modrinth 官方", "MCIM 镜像"])

    def test_window_exposes_needed_api(self):
        for name in ("add_item", "set_items", "resolve", "pending_count",
                     "has_pending", "pending_rels", "current_rel",
                     "report_retry", "show_window", "hide_window", "destroy"):
            self.assertTrue(hasattr(self.Window, name),
                            f"PendingWindow 缺少 {name}")
        sig = inspect.signature(self.Window.__init__)
        self.assertIn("on_notice", sig.parameters)
        self.assertIn("on_give_up", sig.parameters)

    # -- 拖入匹配 -------------------------------------------------------
    def test_candidates_exact_and_fuzzy(self):
        P = self.P
        rels = ["mods/foo-1.0.jar"]
        self.assertEqual(P.match_candidates("foo-1.0.jar", rels),
                         ["mods/foo-1.0.jar"])
        self.assertEqual(P.match_candidates("FOO-1.0.JAR", rels),
                         ["mods/foo-1.0.jar"])
        self.assertEqual(P.match_candidates("foo-1.0 (1).jar", rels),
                         ["mods/foo-1.0.jar"])

    def test_candidates_single_remaining_fallback(self):
        P = self.P
        self.assertEqual(P.match_candidates("完全不相干的名字.jar",
                                            ["mods/foo-1.0.jar"]),
                         ["mods/foo-1.0.jar"])

    def test_candidates_ambiguous_returns_none_path(self):
        P = self.P
        self.assertEqual(P.match_candidates("c.jar",
                                            ["mods/a.jar", "mods/b.jar"]),
                         [])

    # -- 拖入结果反馈（走子窗口的每页拖入框） -----------------------------
    def test_drop_auto_switches_to_the_right_page(self):
        """拖进来的文件属于别的页 → 自动切页并完成补入。"""
        notices = []
        panel, calls = self._panel([
            self._item("mods/a.jar", ["u"]),
            self._item("mods/b.jar", ["u"]),
        ], drop_handler=lambda rel, path: rel == "mods/b.jar",
            notice=lambda lv, t: notices.append((lv, t)))
        self.assertEqual(panel.current_rel(), "mods/a.jar")
        panel._handle_drop("mods/a.jar", [Path("/tmp/b.jar")])
        # 回调里记的是 str(Path)：Windows 上会变成 \tmp\b.jar，别写死正斜杠
        self.assertEqual(calls, [("mods/b.jar", str(Path("/tmp/b.jar")))])
        self.assertEqual(panel.pending_rels(), ["mods/a.jar"],
                         "校验通过的那一页应当被关掉，其余页保留")
        self.assertTrue(any("已切换到那一页" in t for _lv, t in notices),
                        f"没有提示自动切页：{notices}")

    def test_drop_success_removes_item(self):
        notices = []
        panel, calls = self._panel(
            [self._item("mods/a.jar", ["u"])],
            notice=lambda lv, t: notices.append((lv, t)))
        panel._handle_drop("mods/a.jar", [Path("/tmp/a.jar")])
        self.assertEqual(calls, [("mods/a.jar", str(Path("/tmp/a.jar")))])
        self.assertFalse(panel.has_pending())

    def test_drop_mismatch_reports(self):
        notices = []
        panel, calls = self._panel(
            [self._item("mods/a.jar", ["u"]),
             self._item("mods/b.jar", ["u"])],
            notice=lambda lv, t: notices.append((lv, t)))
        panel._handle_drop("mods/a.jar", [Path("/tmp/zzz.jar")])
        self.assertEqual(calls, [])
        self.assertTrue(any("不在待补入列表" in t for _lv, t in notices),
                        f"没有给出提示：{notices}")
        self.assertTrue(panel.has_pending())

    def test_drop_verify_failure_reports(self):
        notices = []
        panel, calls = self._panel(
            [self._item("mods/a.jar", ["u"])],
            drop_handler=lambda rel, path: False,
            notice=lambda lv, t: notices.append((lv, t)))
        panel._handle_drop("mods/a.jar", [Path("/tmp/a.jar")])
        self.assertEqual(len(calls), 1)
        self.assertTrue(any("校验未通过" in t for _lv, t in notices),
                        f"没有给出提示：{notices}")
        self.assertTrue(panel.has_pending(),
                        "校验不过的项应当留着继续让用户试")


class TestConfigConsistency(unittest.TestCase):
    """配置三处（downloader._DEFAULTS / database 默认值 / 首选项类型）不许漂移。"""

    @classmethod
    def setUpClass(cls):
        stubs.install()
        from app.core import database as db
        cls.db = db
        from app.core import downloader as dl
        cls.dl = dl
        # 程序配置目录 / 数据库目录 / 最近列表全部指到临时目录，
        # 测试绝不写工作区外的真实文件
        cls._tmp = tempfile.TemporaryDirectory(prefix="easier-cfg-")
        cls._restore = stubs.isolate_user_dirs(cls._tmp.name)
        cls._dbdir = Path(cls._tmp.name) / "db"
        cls._dbdir.mkdir(parents=True, exist_ok=True)
        db.set_db_path(cls._dbdir)

    @classmethod
    def tearDownClass(cls):
        cls._restore()
        cls._tmp.cleanup()

    # 原项目既有差异（本次不做行为变更，仅记录）
    KNOWN_PREEXISTING_DIFFS: ClassVar[set[str]] = {"multi_slots"}

    def test_defaults_match_database(self):
        dl_def = self.dl._DEFAULTS
        db_def = self.db.DEFAULT_DOWNLOAD_OPTIONS
        for key, value in dl_def.items():
            self.assertIn(key, db_def,
                          f"database.DEFAULT_DOWNLOAD_OPTIONS 缺少 {key}")
            if key in self.KNOWN_PREEXISTING_DIFFS:
                continue
            self.assertEqual(db_def[key], value,
                             f"{key} 默认值不一致："
                             f"downloader={value!r} database={db_def[key]!r}")

    def test_meta_keys_exist(self):
        for key, _label, _desc, _eg in self.db.DOWNLOAD_OPTION_META:
            self.assertIn(key, self.db.DEFAULT_DOWNLOAD_OPTIONS,
                          f"首选项里的 {key} 不在默认配置中")

    def test_preferences_types_cover_new_keys(self):
        from app.ui.widgets import preferences_dialog as pd
        bad = []
        for key, _label, _desc, _eg in self.db.DOWNLOAD_OPTION_META:
            default = self.db.DEFAULT_DOWNLOAD_OPTIONS.get(key)
            raw = str(default)
            try:
                if key in pd._INT_KEYS:
                    got = int(raw)
                elif key in pd._FLOAT_KEYS:
                    got = float(raw)
                else:
                    got = raw
            except (TypeError, ValueError):
                bad.append((key, default))
                continue
            if isinstance(default, bool):
                continue
            if isinstance(default, int) and key not in pd._INT_KEYS:
                bad.append((key, "整数未登记到 _INT_KEYS"))
            if isinstance(default, float) and key not in pd._FLOAT_KEYS:
                bad.append((key, "浮点未登记到 _FLOAT_KEYS"))
            if not isinstance(default, (int, float)) and got is None:
                bad.append((key, "取值失败"))
        self.assertEqual(bad, [], f"首选项类型登记不一致：{bad}")

    def test_get_download_options_contains_all_defaults(self):
        opts = self.db.get_download_options()
        for key in self.dl._DEFAULTS:
            self.assertIn(key, opts, f"get_download_options 缺少 {key}")

    def test_set_and_reload_roundtrip(self):
        self.db.set_download_options({"multi_slots": 6,
                                      "read_poll_interval": 0.5,
                                      "part_meta_enabled": 0})
        opts = self.db.get_download_options()
        self.assertEqual(opts["multi_slots"], 6)
        self.assertEqual(opts["read_poll_interval"], 0.5)
        self.assertEqual(opts["part_meta_enabled"], 0)
        # 未修改的键必须保留
        self.assertEqual(opts["multi_slots"], 6)
        self.assertEqual(opts["engine"],
                         self.db.DEFAULT_DOWNLOAD_OPTIONS["engine"])


class TestAnimationTween(unittest.TestCase):
    """补间核心：按真实时间推进（慢帧不拖长动画）+ 折叠高度补间。"""

    class _FakeWidget:
        """只实现 Tween / toggle_height 需要的那几个方法。"""

        def __init__(self, height: int = 1, natural: int = 120):
            self.scheduled: list = []
            self.heights: list = []
            self._h = height
            self._natural = natural

        def winfo_exists(self):
            return True

        def winfo_height(self):
            return self._h

        def winfo_reqheight(self):
            return self._natural

        def update_idletasks(self):
            pass

        def after(self, ms, fn, *args):
            self.scheduled.append((ms, fn))
            return f"id{len(self.scheduled)}"

        def after_cancel(self, _aid):
            pass

        def grid(self):
            pass

        def grid_remove(self):
            pass

        def grid_propagate(self, *_a):
            pass

        def pack_propagate(self, *_a):
            pass

        def configure(self, **kw):
            if "height" in kw:
                self._h = int(kw["height"])
                self.heights.append(self._h)

    def setUp(self):
        from app.utils import animation
        self.animation = animation
        self.clock = [0.0]
        self._real = animation.time.perf_counter
        animation.time.perf_counter = lambda: self.clock[0]
        self.addCleanup(setattr, animation.time, "perf_counter", self._real)

    def _drive(self, widget, step_ms: float = 20.0, guard: int = 500) -> int:
        """手动跑帧：每"帧"把假时钟往前推 step_ms。"""
        n = 0
        while widget.scheduled and n < guard:
            n += 1
            _ms, fn = widget.scheduled.pop(0)
            self.clock[0] += step_ms / 1000.0
            fn()
        return n

    def test_slow_frames_do_not_stretch_duration(self):
        """一帧卡 40ms 时，总时长仍≈目标时长（不是 帧数×40ms）。"""
        w = self._FakeWidget()
        seen = []
        self.animation.Tween(
            w, 100, lambda e, r: seen.append((self.clock[0] * 1000, e)))
        self._drive(w, step_ms=40.0)
        self.assertLessEqual(self.clock[0] * 1000, 100 + 40 + 1e-6)
        self.assertEqual(seen[-1][1], 1.0)      # 最后一帧一定到位
        self.assertFalse(w.scheduled)

    def test_cancel_stops_scheduling(self):
        w = self._FakeWidget()
        tw = self.animation.Tween(w, 200, lambda e, r: None)
        tw.cancel()
        while w.scheduled:
            _ms, fn = w.scheduled.pop(0)
            fn()
        self.assertEqual(w.scheduled, [])

    def test_toggle_height_expands_then_collapses(self):
        w = self._FakeWidget(height=1, natural=120)
        self.animation.toggle_height(w, True, duration_ms=100)
        self._drive(w, step_ms=20.0)
        self.assertEqual(w.heights[0], 0)       # 先压成 0，避免闪一帧全高
        self.assertEqual(w.heights[-1], 120)    # 补到自然高度

        w2 = self._FakeWidget(height=120, natural=120)
        self.animation.toggle_height(w2, False, duration_ms=100)
        self._drive(w2, step_ms=20.0)
        self.assertEqual(w2.heights[-1], 0)     # 收起补到 0


class TestSegmentedSwitch(unittest.TestCase):
    """自绘分段切换（替代 CTkSegmentedButton）：接口与选中逻辑。"""

    def _make(self, values=("玩家", "开发者"), command=None):
        from app.ui.widgets.segmented_switch import SegmentedSwitch
        return SegmentedSwitch(None, values=list(values), command=command)

    def test_defaults_to_first_value(self):
        sw = self._make()
        self.assertEqual(sw.get(), "玩家")

    def test_set_does_not_fire_command(self):
        calls = []
        sw = self._make(command=calls.append)
        sw.set("开发者")
        self.assertEqual(sw.get(), "开发者")
        self.assertEqual(calls, [])

    def test_select_fires_command_once(self):
        calls = []
        sw = self._make(command=calls.append)
        sw.select("开发者")
        self.assertEqual(calls, ["开发者"])
        sw.select("开发者")            # 重复点同一段不再回调
        self.assertEqual(calls, ["开发者"])

    def test_unknown_value_ignored(self):
        calls = []
        sw = self._make(command=calls.append)
        sw.select("管理员")
        self.assertEqual(sw.get(), "玩家")
        self.assertEqual(calls, [])

    def test_has_sliding_highlight_bar(self):
        sw = self._make()
        self.assertTrue(hasattr(sw, "_bar"), "缺少高亮条（canvas 版没有这个）")
        self.assertEqual(sw._bar_target_x(0), 0)
        self.assertGreater(sw._bar_target_x(1), 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
