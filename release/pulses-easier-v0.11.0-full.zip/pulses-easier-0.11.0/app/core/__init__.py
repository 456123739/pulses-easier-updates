"""Pulses Easier"""
__version__ = "0.11.0"