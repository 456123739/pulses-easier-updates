"""Pulses Easier"""
__version__ = "0.8.1"